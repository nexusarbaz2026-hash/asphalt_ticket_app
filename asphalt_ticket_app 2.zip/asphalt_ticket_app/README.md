# Asphalt One — Ticketing App

A Flutter app for entering Asphalt Mix Tickets, printing them on your
Epson LQ-690 II onto your existing pre-printed ticket stock, storing
everything in Firebase (shared instantly across Windows, Mac, Web and
eventually the Play Store), and generating professional daily supply
summary reports (PDF + Excel) — always kept separate per company.

---

## 1. What's already built

- **Ticket entry screen** — every field from your paper ticket (Date,
  Time Loaded, Type of Mix, Quantity (Ton), Temp, Customer Name,
  Project/J.O. No., Others, Truck Number, Truck Driver, Site Temp,
  Project Supvr., Arr. Job, Received By, Dep. Job, Job Site Name &
  Number), plus AM/PM pickers, date/time defaulting to "now", an
  internal-only Serial No. field, and a live list of today's entries
  below the form.
- **Printing** — "Save & Print" sends exactly one PDF page, sized to
  your ticket, to the OS print dialog. One click = one ticket = one
  physical page, so it naturally stops after each ticket until you
  print the next one. Only the *values* are printed — not labels or
  borders — since those already exist on your paper stock.
- **Print Calibration screen** — a visual tool to nudge every field's
  X/Y position (in millimetres) until it lands on the correct blank
  line, with a one-tap test print. Saved per company in Firestore.
- **Firebase (Firestore)** — every company's tickets live in their own
  subcollection (`companies/{id}/tickets`), so data is never mixed.
- **Reports screen** — pick a date range, generate a styled PDF (A4,
  company header banner, bordered/striped table, totals box, page
  numbers) and a styled Excel workbook (merged colored title rows,
  colored header row, bold totals row, sensible column widths) — one
  pair of files per company, saved to local storage and shareable.
- **Multi-company management** — add/edit companies; every screen is
  scoped to whichever company is selected at the top of the app.
- **Login screen** — simple email/password so every device needs a
  sign-in before it can touch your data.

Project structure:
```
lib/
  main.dart
  firebase_options.dart      <- placeholder, see step 2
  theme/app_theme.dart
  models/                    company.dart, ticket.dart, printer_profile.dart
  services/                  firebase_service.dart, auth_service.dart,
                              print_service.dart, export_service.dart
  screens/                   login, home, ticket_entry, reports,
                              calibration, company_management
  widgets/                   app_header.dart, company_selector.dart
assets/images/header.jpg     <- your logo banner (Image 1)
firestore.rules
```

---

## 2. One-time setup

You said you already have a Firebase account on **nexusarbaz2023@gmail.com**
— use that account for all of this.

1. Install Flutter: https://docs.flutter.dev/get-started/install (pick
   macOS, since you're developing on a Mac; enable Windows/Web/Android
   platforms too — Flutter supports all four from one install).
2. `cd` into this project folder, then:
   ```bash
   flutter pub get
   ```
3. Install the FlutterFire CLI and connect the project to Firebase:
   ```bash
   dart pub global activate flutterfire_cli
   flutterfire configure
   ```
   - Sign in with nexusarbaz2023@gmail.com when prompted.
   - Choose an existing Firebase project or create a new one.
   - When asked "Which platforms?", tick **macOS, Windows, Web,
     Android** (iOS too if you might want it later).
   - This overwrites the placeholder `lib/firebase_options.dart` with
     real config for every platform — that's expected and correct.
4. In the Firebase console for that project:
   - **Build → Firestore Database → Create database** (production
     mode is fine).
   - **Build → Authentication → Sign-in method → Email/Password →
     Enable**.
   - **Authentication → Users → Add user** — create a login for
     yourself (and anyone else who'll use the app).
5. Deploy the security rules in `firestore.rules` (or paste them
   straight into Firestore → Rules in the console and click Publish).

Run it:
```bash
flutter run -d macos     # or: -d windows / -d chrome / -d android
```

---

## 3. First run: add your company + calibrate printing

1. Sign in.
2. Go to the **Companies** tab → **Add company** → enter its name
   (and address/C.R./VAT if you want them on your reports). Repeat for
   every company/branch whose tickets you want kept separate.
3. Go to **Print Calibration**. The starting positions are a
   **reasonable guess**, not a measurement — I can't get exact
   millimetres off a phone photo. Load one blank ticket into the
   LQ-690 II, tap **Test print**, compare it to the paper, select each
   field and nudge it with the arrows until it lines up, then **Save**.
   You only need to do this once per ticket-book design; it's stored
   in Firestore so every computer picks it up automatically.
4. On Windows/Mac, also check the LQ-690 II's own paper size in the OS
   printer settings — set a **custom paper size** matching the "Page
   width/height" numbers on the Calibration screen, so the printer
   itself feeds the correct amount of paper per ticket.
5. Go to **New Ticket**, fill it in, **Save & Print**.

---

## 4. Reports

**Reports** tab → pick a date range → **Generate PDF + Excel**. Both
files:
- cover the one company currently selected, never several at once
  (generate again after switching company for another company's set),
- are saved under your Documents folder in `AsphaltTicketReports/`,
- can be shared/emailed straight from the app via the share icon,
- use A4 page size and paginate automatically for large date ranges.

---

## 5. Known limitations / things to double-check before you rely on it

- **Calibration numbers are a starting guess**, as above — budget 10
  minutes with a real blank ticket the first time.
- **The `excel` package's API changes between versions.** I pinned
  `excel: ^4.0.6` in `pubspec.yaml` and wrote `export_service.dart`
  against that version's API as I know it, but if `flutter pub get`
  resolves a slightly different version and you get red squiggles in
  that one file, it's almost always a `CellStyle`/`TextCellValue`
  signature change — the fix is usually mechanical (check the
  package's current docs on pub.dev for the exact constructor).
- **Raw ESC/P mode isn't implemented.** This app prints via a
  rendered PDF through the OS print dialog, which is simpler and works
  identically on Windows/Mac/Web/Android. If the LQ-690 II's Windows
  driver ever prints noticeably slower or the alignment drifts in a
  way calibration can't fix, the alternative is sending raw ESC/P text
  commands directly to the printer port (Windows-only, more brittle,
  more precise) — that's a separate, smaller addition if you ever need
  it.
- **No offline mode yet.** Firestore does cache locally, but this app
  hasn't been configured to force offline persistence — if that
  matters at a site with poor signal, it's a small addition
  (`FirebaseFirestore.instance.settings = Settings(persistenceEnabled: true)`).
- I wrote and reviewed all of this code carefully, but I have not been
  able to compile it (no Flutter SDK / printer / your Firebase project
  in this environment) — run `flutter pub get` and `flutter analyze`
  first thing, and treat the first real run as a test pass, not a
  guarantee.

---

## 6. Deploying to the Play Store later

Once you're happy with it:
```bash
flutter build appbundle --release
```
Then follow Google's Play Console steps (new app → upload the
`.aab` from `build/app/outputs/bundle/release/`) — this part is mostly
Play Console paperwork (store listing, content rating, etc.), not
code. Because everything reads/writes the same Firebase project, the
phone app and your Windows/Mac desktop builds will always show the
same data. When you want to push a code update, you just rebuild and
re-upload a new version — no separate backend work needed.
