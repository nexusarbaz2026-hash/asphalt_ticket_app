package com.example.asphalt_ticket_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
